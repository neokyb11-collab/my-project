import { invokeLLM } from "./_core/llm";
import { transcribeAudio, type TranscriptionResponse, type TranscriptionError } from "./_core/voiceTranscription";
import { storageGetSignedUrl } from "./storage";

// ─── Types ────────────────────────────────────────────────────────────────────

export interface TranscriptionWord {
  word: string;
  start: number;
  end: number;
  confidence: number;
}

export interface TranscriptionSegment {
  start: number;
  end: number;
  text: string;
  words: TranscriptionWord[];
}

export interface TranscriptionResult {
  text: string;
  segments: TranscriptionSegment[];
  duration: number;
}

export interface SrtEntry {
  index: number;
  startTime: string;
  endTime: string;
  text: string;
}

export interface LlmSettings {
  preferredLlm?: "claude" | "gemini" | null;
  claudeApiKey?: string | null;
  geminiApiKey?: string | null;
}

export interface TranscriberSettings {
  preferredTranscriber?: "whisper" | "deepgram";
  deepgramApiKey?: string | null;
}

// ─── Transcription ────────────────────────────────────────────────────────────

/**
 * Transcribe audio using Whisper API (Manus built-in).
 *
 * IMPORTANT: storageKey must be converted to a signed URL via
 * storageGetSignedUrl() before being passed to transcribeAudio().
 * This function handles that conversion internally.
 */
export async function transcribeAudioFileWithWhisper(storageKey: string): Promise<TranscriptionResult> {
  const signedUrl = await storageGetSignedUrl(storageKey);

  const result = await transcribeAudio({ audioUrl: signedUrl });

  if ("error" in result) {
    const err = result as TranscriptionError;
    throw new Error(`Whisper transcription failed: ${err.error}${err.details ? ` – ${err.details}` : ""}`);
  }

  const response = result as TranscriptionResponse;
  const segments: TranscriptionSegment[] = [];

  if (response.segments && Array.isArray(response.segments)) {
    for (const segment of response.segments) {
      segments.push({
        start: segment.start,
        end: segment.end,
        text: segment.text ?? "",
        words: [
          {
            word: segment.text ?? "",
            start: segment.start,
            end: segment.end,
            confidence: 1.0 - (segment.no_speech_prob ?? 0),
          },
        ],
      });
    }
  }

  return {
    text: response.text ?? "",
    segments,
    duration: response.duration ?? 0,
  };
}

/**
 * Transcribe audio using Deepgram API.
 *
 * Requires a valid Deepgram API key.
 */
export async function transcribeAudioFileWithDeepgram(
  storageKey: string,
  deepgramApiKey: string
): Promise<TranscriptionResult> {
  const signedUrl = await storageGetSignedUrl(storageKey);

  const response = await fetch("https://api.deepgram.com/v1/listen?model=nova-2&punctuate=true", {
    method: "POST",
    headers: {
      Authorization: `Token ${deepgramApiKey}`,
      "Content-Type": "application/json",
    },
    body: JSON.stringify({
      url: signedUrl,
    }),
  });

  if (!response.ok) {
    const err = await response.text().catch(() => "Unknown error");
    throw new Error(`Deepgram transcription failed (${response.status}): ${err}`);
  }

  const data = (await response.json()) as any;

  if (!data.results?.channels?.[0]?.alternatives?.[0]) {
    throw new Error("Deepgram returned unexpected response format");
  }

  const alternative = data.results.channels[0].alternatives[0];
  const segments: TranscriptionSegment[] = [];

  if (alternative.words && Array.isArray(alternative.words)) {
    let currentSegment: TranscriptionSegment | null = null;

    for (const word of alternative.words) {
      if (!currentSegment || word.start - currentSegment.end > 1) {
        if (currentSegment) {
          segments.push(currentSegment);
        }
        currentSegment = {
          start: word.start,
          end: word.end,
          text: word.punctuated_word || word.word,
          words: [],
        };
      } else {
        currentSegment.text += " " + (word.punctuated_word || word.word);
        currentSegment.end = word.end;
      }

      currentSegment.words.push({
        word: word.punctuated_word || word.word,
        start: word.start,
        end: word.end,
        confidence: word.confidence ?? 0.9,
      });
    }

    if (currentSegment) {
      segments.push(currentSegment);
    }
  }

  return {
    text: alternative.transcript ?? "",
    segments,
    duration: data.metadata?.duration ?? 0,
  };
}

/**
 * Transcribe audio using the user's preferred service (Whisper or Deepgram).
 */
export async function transcribeAudioFile(
  storageKey: string,
  transcriberSettings?: TranscriberSettings
): Promise<TranscriptionResult> {
  const preferred = transcriberSettings?.preferredTranscriber ?? "whisper";

  if (preferred === "deepgram" && transcriberSettings?.deepgramApiKey) {
    return transcribeAudioFileWithDeepgram(storageKey, transcriberSettings.deepgramApiKey);
  }

  // Default to Whisper
  return transcribeAudioFileWithWhisper(storageKey);
}

// ─── Merge ────────────────────────────────────────────────────────────────────

export function mergeTranscriptions(
  transcriptions: TranscriptionResult[]
): { merged: TranscriptionSegment[]; totalDuration: number } {
  const merged: TranscriptionSegment[] = [];
  let currentOffset = 0;
  let totalDuration = 0;

  for (const transcription of transcriptions) {
    const offsetSegments = transcription.segments.map((seg) => ({
      ...seg,
      start: seg.start + currentOffset,
      end: seg.end + currentOffset,
    }));
    merged.push(...offsetSegments);
    currentOffset += transcription.duration;
    totalDuration += transcription.duration;
  }

  return { merged, totalDuration };
}

// ─── SRT helpers ──────────────────────────────────────────────────────────────

export function secondsToSrtTime(seconds: number): string {
  const hours = Math.floor(seconds / 3600);
  const minutes = Math.floor((seconds % 3600) / 60);
  const secs = Math.floor(seconds % 60);
  const ms = Math.floor((seconds % 1) * 1000);
  return [
    String(hours).padStart(2, "0"),
    String(minutes).padStart(2, "0"),
    String(secs).padStart(2, "0"),
  ].join(":") + "," + String(ms).padStart(3, "0");
}

export function generateSrtContent(entries: SrtEntry[]): string {
  return entries
    .map((e) => `${e.index}\n${e.startTime} --> ${e.endTime}\n${e.text}\n`)
    .join("\n");
}

// ─── LLM alignment ────────────────────────────────────────────────────────────

/**
 * Use LLM to align script lines with transcription segments and produce SRT entries.
 *
 * When llmSettings is provided, the function attempts to use the user's preferred
 * LLM provider (Claude or Gemini) with their stored API key. If no external key is
 * configured, it falls back to the Manus built-in Forge LLM (Gemini 2.5 Flash).
 */
export async function generateSubtitlesWithLLM(
  script: string,
  transcriptionSegments: TranscriptionSegment[],
  llmSettings?: LlmSettings
): Promise<SrtEntry[]> {
  const transcriptionText = transcriptionSegments
    .map(
      (seg) =>
        `[${secondsToSrtTime(seg.start)} - ${secondsToSrtTime(seg.end)}] ${seg.text}`
    )
    .join("\n");

  const prompt = `You are a subtitle synchronization expert. Align the following script with the transcription timestamps and generate SRT subtitle entries.

SCRIPT (each line is one subtitle):
${script}

TRANSCRIPTION WITH TIMESTAMPS:
${transcriptionText}

Instructions:
1. Match each script line to the most appropriate transcription segment(s).
2. Assign start/end times from the transcription.
3. Keep subtitle text exactly as written in the script (do not use transcription text).
4. Ensure smooth, non-overlapping transitions.
5. Return ONLY a valid JSON array, no other text.

Output format:
[
  {"index": 1, "startTime": "00:00:01,000", "endTime": "00:00:04,500", "text": "Script line here"},
  ...
]`;

  // Determine which LLM to call
  const preferred = llmSettings?.preferredLlm ?? "gemini";
  const claudeKey = llmSettings?.claudeApiKey;
  const geminiKey = llmSettings?.geminiApiKey;

  let content = "";

  if (preferred === "claude" && claudeKey) {
    // Call Claude API directly
    content = await callClaudeApi(claudeKey, prompt);
  } else if (preferred === "gemini" && geminiKey) {
    // Call Gemini API directly
    content = await callGeminiApi(geminiKey, prompt);
  } else {
    // Fall back to Manus built-in Forge LLM
    const response = await invokeLLM({
      messages: [
        { role: "system", content: "You are a subtitle synchronization expert. Return only valid JSON." },
        { role: "user", content: prompt },
      ],
    });

    const raw = response.choices[0]?.message?.content;
    if (typeof raw === "string") {
      content = raw;
    } else if (Array.isArray(raw)) {
      for (const item of raw) {
        if (typeof item === "string") content += item;
        else if (item && typeof item === "object" && "text" in item) content += (item as any).text;
      }
    }
  }

  const jsonMatch = content.match(/\[\s*\{[\s\S]*?\}\s*\]/);
  if (!jsonMatch) {
    throw new Error("LLM did not return a valid JSON array. Response: " + content.substring(0, 300));
  }

  const entries: SrtEntry[] = JSON.parse(jsonMatch[0]);
  if (!Array.isArray(entries) || entries.length === 0) {
    throw new Error("LLM returned an empty subtitle list.");
  }
  return entries;
}

// ─── External LLM helpers ─────────────────────────────────────────────────────

async function callClaudeApi(apiKey: string, prompt: string): Promise<string> {
  const response = await fetch("https://api.anthropic.com/v1/messages", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      "x-api-key": apiKey,
      "anthropic-version": "2023-06-01",
    },
    body: JSON.stringify({
      model: "claude-3-5-haiku-20241022",
      max_tokens: 8192,
      system: "You are a subtitle synchronization expert. Return only valid JSON.",
      messages: [{ role: "user", content: prompt }],
    }),
  });

  if (!response.ok) {
    const err = await response.text().catch(() => "");
    throw new Error(`Claude API error (${response.status}): ${err}`);
  }

  const data = await response.json() as any;
  return data.content?.[0]?.text ?? "";
}

async function callGeminiApi(apiKey: string, prompt: string): Promise<string> {
  const url = `https://generativelanguage.googleapis.com/v1beta/models/gemini-1.5-flash:generateContent?key=${apiKey}`;
  const response = await fetch(url, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      contents: [
        {
          parts: [
            { text: "You are a subtitle synchronization expert. Return only valid JSON.\n\n" + prompt },
          ],
        },
      ],
      generationConfig: { maxOutputTokens: 8192 },
    }),
  });

  if (!response.ok) {
    const err = await response.text().catch(() => "");
    throw new Error(`Gemini API error (${response.status}): ${err}`);
  }

  const data = await response.json() as any;
  return data.candidates?.[0]?.content?.parts?.[0]?.text ?? "";
}
