import { invokeLLM } from "./_core/llm";
import { transcribeAudio, type TranscriptionResponse, type TranscriptionError } from "./_core/voiceTranscription";
import { storageGetSignedUrl } from "./storage";

export interface TranscriptionWord {
  word: string;
  start: number;
  end: number;
  confidence: number;
}

export interface TranscriptionSegment {
  start: number;
  end: number;
  text: string;
  words: TranscriptionWord[];
}

export interface TranscriptionResult {
  text: string;
  segments: TranscriptionSegment[];
  duration: number;
}

export interface SrtEntry {
  index: number;
  startTime: string;
  endTime: string;
  text: string;
}

export interface LlmSettings {
  preferredLlm?: "claude" | "gemini" | null;
  claudeApiKey?: string | null;
  geminiApiKey?: string | null;
}

export interface TranscriberSettings {
  preferredTranscriber?: "whisper" | "deepgram";
  deepgramApiKey?: string | null;
}

export async function transcribeAudioFileWithWhisper(storageKey: string): Promise<TranscriptionResult> {
  const signedUrl = await storageGetSignedUrl(storageKey);
  const result = await transcribeAudio({ audioUrl: signedUrl });
  if ("error" in result) {
    const err = result as TranscriptionError;
    throw new Error(`Whisper transcription failed: ${err.error}${err.details ? ` – ${err.details}` : ""}`);
  }
  const response = result as TranscriptionResponse;
  const segments: TranscriptionSegment[] = [];
  if (response.segments && Array.isArray(response.segments)) {
    for (const segment of response.segments) {
      segments.push({
        start: segment.start,
        end: segment.end,
        text: segment.text ?? "",
        words: [{ word: segment.text ?? "", start: segment.start, end: segment.end, confidence: 1.0 - (segment.no_speech_prob ?? 0) }],
      });
    }
  }
  return { text: response.text ?? "", segments, duration: response.duration ?? 0 };
}

export async function transcribeAudioFileWithDeepgram(storageKey: string, deepgramApiKey: string): Promise<TranscriptionResult> {
  const signedUrl = await storageGetSignedUrl(storageKey);
  const response = await fetch("https://api.deepgram.com/v1/listen?model=nova-2&punctuate=true", {
    method: "POST",
    headers: { Authorization: `Token ${deepgramApiKey}`, "Content-Type": "application/json" },
    body: JSON.stringify({ url: signedUrl }),
  });
  if (!response.ok) {
    const err = await response.text().catch(() => "Unknown error");
    throw new Error(`Deepgram transcription failed (${response.status}): ${err}`);
  }
  const data = (await response.json()) as any;
  if (!data.results?.channels?.[0]?.alternatives?.[0]) throw new Error("Deepgram returned unexpected response format");
  const alternative = data.results.channels[0].alternatives[0];
  const segments: TranscriptionSegment[] = [];
  if (alternative.words && Array.isArray(alternative.words)) {
    let currentSegment: TranscriptionSegment | null = null;
    for (const word of alternative.words) {
      if (!currentSegment || word.start - currentSegment.end > 1) {
        if (currentSegment) segments.push(currentSegment);
        currentSegment = { start: word.start, end: word.end, text: word.punctuated_word || word.word, words: [] };
      } else {
        currentSegment.text += " " + (word.punctuated_word || word.word);
        currentSegment.end = word.end;
      }
      currentSegment.words.push({ word: word.punctuated_word || word.word, start: word.start, end: word.end, confidence: word.confidence ?? 0.9 });
    }
    if (currentSegment) segments.push(currentSegment);
  }
  return { text: alternative.transcript ?? "", segments, duration: data.metadata?.duration ?? 0 };
}

export async function transcribeAudioFile(storageKey: string, transcriberSettings?: TranscriberSettings): Promise<TranscriptionResult> {
  const preferred = transcriberSettings?.preferredTranscriber ?? "whisper";
  if (preferred === "deepgram" && transcriberSettings?.deepgramApiKey) {
    return transcribeAudioFileWithDeepgram(storageKey, transcriberSettings.deepgramApiKey);
  }
  return transcribeAudioFileWithWhisper(storageKey);
}

export function mergeTranscriptions(transcriptions: TranscriptionResult[]): { merged: TranscriptionSegment[]; totalDuration: number } {
  const merged: TranscriptionSegment[] = [];
  let currentOffset = 0;
  let totalDuration = 0;
  for (const transcription of transcriptions) {
    const offsetSegments = transcription.segments.map((seg) => ({ ...seg, start: seg.start + currentOffset, end: seg.end + currentOffset }));
    merged.push(...offsetSegments);
    currentOffset += transcription.duration;
    totalDuration += transcription.duration;
  }
  return { merged, totalDuration };
}

export function secondsToSrtTime(seconds: number): string {
  const hours = Math.floor(seconds / 3600);
  const minutes = Math.floor((seconds % 3600) / 60);
  const secs = Math.floor(seconds % 60);
  const ms = Math.floor((seconds % 1) * 1000);
  return [String(hours).padStart(2, "0"), String(minutes).padStart(2, "0"), String(secs).padStart(2, "0")].join(":") + "," + String(ms).padStart(3, "0");
}

export function generateSrtContent(entries: SrtEntry[]): string {
  return entries.map((e) => `${e.index}\n${e.startTime} --> ${e.endTime}\n${e.text}\n`).join("\n");
}

export async function generateSubtitlesWithLLM(
  script: string,
  transcriptionSegments: TranscriptionSegment[],
  llmSettings?: LlmSettings
): Promise<SrtEntry[]> {
  const scriptLines = script.split("\n").filter(line => line.trim() !== "");
  const CHUNK_SIZE = 20;
  const chunks: string[][] = [];
  for (let i = 0; i < scriptLines.length; i += CHUNK_SIZE) {
    chunks.push(scriptLines.slice(i, i + CHUNK_SIZE));
  }

  const preferred = llmSettings?.preferredLlm ?? "gemini";
  const claudeKey = llmSettings?.claudeApiKey;
  const geminiKey = llmSettings?.geminiApiKey;
  const allEntries: SrtEntry[] = [];

  for (let chunkIdx = 0; chunkIdx < chunks.length; chunkIdx++) {
    const chunkLines = chunks[chunkIdx];
    const chunkScript = chunkLines.join("\n");
    const chunkStartRatio = chunkIdx / chunks.length;
    const chunkEndRatio = (chunkIdx + 1) / chunks.length;
    const totalDuration = transcriptionSegments.length > 0 ? transcriptionSegments[transcriptionSegments.length - 1].end : 0;
    const chunkStartTime = totalDuration * chunkStartRatio;
    const chunkEndTime = totalDuration * chunkEndRatio;
    const buffer = totalDuration * 0.1;
    const relevantSegments = transcriptionSegments.filter(seg => seg.end >= chunkStartTime - buffer && seg.start <= chunkEndTime + buffer);
    const segmentsToUse = relevantSegments.length > 0 ? relevantSegments : transcriptionSegments;
    const transcriptionText = segmentsToUse.map(seg => `[${secondsToSrtTime(seg.start)} - ${secondsToSrtTime(seg.end)}] ${seg.text}`).join("\n");

    const prompt = `You are a professional subtitle synchronization expert. Your task is to precisely align each script line with the audio transcription timestamps.

SCRIPT (numbered lines, each = one subtitle):
${chunkScript}

TRANSCRIPTION WITH TIMESTAMPS:
${transcriptionText}

Critical Instructions:
1. Process ALL script lines from start to finish WITHOUT skipping any.
2. For each script line, find the matching transcription segment by comparing meaning/content (not exact wording).
3. Use the transcription timestamps as the source of truth for timing.
4. If a script line spans multiple transcription segments, use the start of the first and end of the last.
5. Subtitles must be strictly sequential - each startTime must be >= previous endTime.
6. Do NOT reuse or repeat timestamps - every subtitle must advance forward in time.
7. Keep the script text EXACTLY as written - do not modify it.
8. Make sure EVERY script line gets a subtitle entry.

Common mistakes to avoid:
- Do not bunch multiple script lines into one timestamp range
- Do not skip lines
- Do not let timestamps go backwards or overlap

Return ONLY a valid JSON array with no additional text:
[
  {"index": 1, "startTime": "00:00:01,000", "endTime": "00:00:04,500", "text": "Script line here"},
  ...
]`;

    let content = "";
    if (preferred === "claude" && claudeKey) {
      content = await callClaudeApi(claudeKey, prompt);
    } else if (preferred === "gemini" && geminiKey) {
      content = await callGeminiApi(geminiKey, prompt);
    } else {
      const response = await invokeLLM({
        messages: [
          { role: "system", content: "You are a subtitle synchronization expert. Return only valid JSON." },
          { role: "user", content: prompt },
        ],
      });
      const raw = response.choices[0]?.message?.content;
      if (typeof raw === "string") {
        content = raw;
      } else if (Array.isArray(raw)) {
        for (const item of raw) {
          if (typeof item === "string") content += item;
          else if (item && typeof item === "object" && "text" in item) content += (item as any).text;
        }
      }
    }

    const jsonMatch = content.match(/\[[\s\S]*\]/);
    if (!jsonMatch) {
      throw new Error(`LLM chunk ${chunkIdx + 1} returned invalid JSON. Response: ${content.substring(0, 200)}`);
    }
    let chunkEntries: SrtEntry[];
    try {
      chunkEntries = JSON.parse(jsonMatch[0]);
    } catch (e) {
      throw new Error(`LLM chunk ${chunkIdx + 1} JSON parse error: ${(e as Error).message}`);
    }
    if (Array.isArray(chunkEntries)) {
      allEntries.push(...chunkEntries);
    }
  }

  if (allEntries.length === 0) throw new Error("LLM returned an empty subtitle list.");

  const sorted = allEntries.sort((a, b) => a.index - b.index);
  const seen = new Set<number>();
  const deduped = sorted.filter(entry => {
    if (seen.has(entry.index)) return false;
    seen.add(entry.index);
    return true;
  });
  return deduped.map((entry, i) => ({ ...entry, index: i + 1 }));
}

async function callClaudeApi(apiKey: string, prompt: string): Promise<string> {
  const response = await fetch("https://api.anthropic.com/v1/messages", {
    method: "POST",
    headers: { "Content-Type": "application/json", "x-api-key": apiKey, "anthropic-version": "2023-06-01" },
    body: JSON.stringify({
      model: "claude-sonnet-4-5",
      max_tokens: 8192,
      system: "You are a subtitle synchronization expert. Return only valid JSON.",
      messages: [{ role: "user", content: prompt }],
    }),
  });
  if (!response.ok) {
    const err = await response.text().catch(() => "");
    throw new Error(`Claude API error (${response.status}): ${err}`);
  }
  const data = await response.json() as any;
  return data.content?.[0]?.text ?? "";
}

async function callGeminiApi(apiKey: string, prompt: string): Promise<string> {
  const url = `https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash-preview-04-17:generateContent?key=${apiKey}`;
  const response = await fetch(url, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      contents: [{ parts: [{ text: "You are a subtitle synchronization expert. Return only valid JSON.\n\n" + prompt }] }],
      generationConfig: { maxOutputTokens: 8192 },
    }),
  });
  if (!response.ok) {
    const err = await response.text().catch(() => "");
    throw new Error(`Gemini API error (${response.status}): ${err}`);
  }
  const data = await response.json() as any;
  return data.candidates?.[0]?.content?.parts?.[0]?.text ?? "";
}
